export const path7za: string
export const path7x: string